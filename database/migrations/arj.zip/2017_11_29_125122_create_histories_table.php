<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateHistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('histories', function (Blueprint $table) {
            $table->increments('id');
//            $table->enum('year',
//                [2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028]);
//            $table->enum(
//                'month', [
//                    'January',
//                    'February',
//                    'March',
//                    'April',
//                    'May',
//                    'June',
//                    'July',
//                    'August',
//                    'September',
//                    'October',
//                    'November',
//                    'December'
//                ]
//            );
            $table->dateTime('event_date');
           // $table->unique(['year', 'month']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('histories');
    }
}
